package com.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.spring.dao.StudentDao;
import com.spring.model.Student;
@Service
public class StudentServiceJdbcImpl implements StudentService {
     @Autowired
     @Qualifier("jdbc")
   	 private StudentDao studentDao;
	 
	@Override
	public Student save(Student st) {
		studentDao.save(st);
		return st;
	}

	@Override
	public List<Student> display() {
		// TODO Auto-generated method stub
		return studentDao.display();
	}

	@Override
	public Student update(Student st) {
		// TODO Auto-generated method stub
		return studentDao.update(st);
	}

	@Override
	public Student delete(Student st) {
		// TODO Auto-generated method stub
		return studentDao.delete(st);
	}

}
