package com.spring.client;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.model.Student;
import com.spring.service.StudentService;
import com.spring.service.StudentServiceCollectionImpl;
import com.spring.service.StudentServiceJdbcImpl;

public class MainApp {

	public static void printlist(List<Student> slist) {
		for (Student st : slist) {
			System.out.println(st.getStid() + " " + st.getStname() + " " +st.getMarks());
		}
	}

	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");

		Student s1 = new Student(100, "ravi", 78);
		Student s2 = new Student(101, "ram", 98);
		Student s3 = new Student(102, "narasimha", 56);

		StudentService service = context.getBean(StudentServiceCollectionImpl.class);
		service.save(s1);
		service.save(s2);
		service.save(s3);
		
		
		
		System.out.println("*********inserted list*******");
		List<Student> slist = service.display();

		printlist(slist);
		System.out.println("********updated list*******");
		Student updated = new Student(102, "simha", 56);
		service.update(updated);
		printlist(slist);

		service.delete(updated);
		System.out.println("******remaning list*******");
		printlist(slist);
		((AbstractApplicationContext) context).close();

	}

}







