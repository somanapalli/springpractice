package com.spring.client;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.model.Student;
import com.spring.service.StudentService;
import com.spring.service.StudentServiceJdbcImpl;

public class MainApp2 {
	
	public static void main(String[] args) {
		
		
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		
		StudentService service = context.getBean(StudentServiceJdbcImpl.class);
		
		/*Student st1 = new Student(100,"ram",78);
		service.save(st1);
		

		Student st2 = new Student(101,"rk",79);
		service.save(st2);
		System.out.println("Records added");*/
		
		
		/*List<Student> slist = service.display();
		
		for(Student s:slist)
		{
			System.out.println(s.getStname());
		}
		*/
		
		Student temp = new Student(100,"pavan",78);
		
		 //service.update(temp);
		 service.delete(temp);
	}

}
