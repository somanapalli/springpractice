package com.spring.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.spring.model.Student;

@Repository("jdbc")
public class StudentDaoJdbcImpl implements StudentDao{

	@Autowired
	
	private JdbcTemplate jdbcTemplate;
	@Override
	public Student save(Student st) {
		jdbcTemplate.update(StudentDao.insertCommand,new Object[]{st.getStid(),st.getStname(),st.getMarks()});
		return st;
	}

	@Override
	public List<Student> display() {
		
		List<Student> slist = jdbcTemplate.query(StudentDao.selectCommand, new RowMapper<Student>(){

			@Override
			public Student mapRow(ResultSet rs, int rowNum) throws SQLException {
				Student st = new Student();
				st.setStid(rs.getInt(1));
				st.setStname(rs.getString(2));
				st.setMarks(rs.getDouble(3));
				return st;
			}});
		return slist;
		 
	}

	@Override
	public Student update(Student st) {
		jdbcTemplate.update(StudentDao.updateCommand,new Object[]{st.getMarks(),st.getStname(),st.getStid()});
		return st;
	}

	@Override
	public Student delete(Student st) {
		jdbcTemplate.update(StudentDao.deleteCommand,new Object[]{st.getStid()});
		return st;
	}

}
