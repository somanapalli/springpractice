package com.spring.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.spring.model.Student;

@Repository("collection")
public class StudentDaoCollectionImpl implements StudentDao{

	List<Student> list = new ArrayList<Student>();
	
	@Override
	public Student save(Student st) {
		 
		list.add(st);
		//System.out.println("record added");
		return st;
		
		
	}

	@Override
	public List<Student> display() {
		// TODO Auto-generated method stub
		return list;
	}

	@Override
	public Student update(Student st) {
		int searchIndex= list.indexOf(st);
		list.set(searchIndex, st);
		//System.out.println("record updated");
		return st;
	}

	@Override
	public Student delete(Student st) {
		// TODO Auto-generated method stub
		
		list.remove(st);
		//System.out.println("Record deleted");
		return st;
		
	}

}
