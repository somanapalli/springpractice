package com.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.dao.StudentDao;
import com.spring.model.Student;

@Service
public class StudentServiceCollectionImpl implements StudentService {

	 @Autowired
	 private StudentDao studentDao;
	 
	@Override
	public Student save(Student st) {
		studentDao.save(st);
		return st;

	}

	@Override
	public List<Student> display() {
		return studentDao.display();
	}

	@Override
	public Student update(Student st) {
		studentDao.update(st);
		return st;

	}

	@Override
	public Student delete(Student st) {
	    studentDao.delete(st);
	    return st;

	}

}
