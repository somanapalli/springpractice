package com.spring.dao;

import java.util.List;

import com.spring.model.Student;


public interface StudentDao {

	 public Student save(Student st);
	 public List<Student> display();
	 public Student update(Student st);
	 public Student delete(Student st);
	 
}
