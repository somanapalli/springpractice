package com.spring.model;

import org.springframework.beans.factory.annotation.Autowired;


public class Student {
	
	
	
	private int stid;
	private String stname;
	private double marks;
	
	public Student(){
		
	}

	public int getStid() {
		return stid;
	}

	public void setStid(int stid) {
		this.stid = stid;
	}

	public String getStname() {
		return stname;
	}

	public void setStname(String stname) {
		this.stname = stname;
	}

	public double getMarks() {
		return marks;
	}

	public void setMarks(double marks) {
		this.marks = marks;
	}

	public Student(int stid, String stname, double marks) {
		super();
		this.stid = stid;
		this.stname = stname;
		this.marks = marks;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + stid;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		if (stid != other.stid)
			return false;
		return true;
	}
	
	
	
}
