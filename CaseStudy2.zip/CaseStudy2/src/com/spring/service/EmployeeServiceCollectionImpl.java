package com.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.dao.EmployeeDao;
import com.spring.model.Employee;

@Service
public class EmployeeServiceCollectionImpl implements EmployeeServiceDao {

	 @Autowired
	private EmployeeDao empDao;
	
	@Override
	public Employee save(Employee emp) {
		
		return empDao.save(emp);
	}

	@Override
	public Employee update(int empid) {
		
		return empDao.update(empid);
	}

	@Override
	public List<Employee> display() {
		// TODO Auto-generated method stub
		return empDao.display();
	}

	@Override
	public boolean delete(int empid) {
		return empDao.delete(empid);
	}

}
