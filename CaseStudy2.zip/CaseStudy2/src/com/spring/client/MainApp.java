package com.spring.client;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.model.Employee;
import com.spring.service.EmployeeServiceCollectionImpl;
import com.spring.service.EmployeeServiceDao;

public class MainApp {
	
	public static void printList(List<Employee> list)
	{
		for(Employee l: list)
		{
			System.out.println(l);
		}
	}
	public static void main(String[] args)
	{
		
		
	   ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		
	   EmployeeServiceDao emp = context.getBean(EmployeeServiceCollectionImpl.class);
	    
	   Employee e1=  emp.save(new Employee(100,"ram",987));
	   Employee e2 = emp.save(new Employee(101,"ravi",866));
	   
	   List<Employee> list =  emp.display();
	   System.out.println("inserted list");
	   printList(list);
	   
	    emp.update(100);
	    System.out.println("Updated list");
	    printList(list);
	   
	   emp.delete(100);
	   System.out.println("remaining list");
	   printList(list);
	}
}
