package com.spring.dao;

import java.util.List;

import com.spring.model.Employee;

public interface EmployeeDao {

	 public Employee save(Employee emp);
	 public Employee update(int empid);
	 public List<Employee> display();
	 public boolean delete(int empid);
	 
}
