package com.spring.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.spring.model.Employee;

@Repository
public class EmployeeDaoCollectionImpl implements EmployeeDao {
	
	List<Employee> list = new ArrayList<Employee>();

	@Override
	public Employee save(Employee emp) {
		
		list.add(emp);
		
		return emp;
	}

	@Override
	public Employee update(int  empid) {
		Employee emp = new Employee(empid,"java",899);
	    list.set(1, emp);
		return emp;
		
	}

	@Override
	public List<Employee> display() {
		
		return list;
	}

	@Override
	public boolean delete(int empid) {
		Employee temp = new Employee();
		temp.setEmpid(empid);
		
		int index = list.indexOf(temp);
		
		Employee emp = list.remove(index);
		
		if(emp!=null)
		return true;
		else return false;
		
		
		
	}

	

}
